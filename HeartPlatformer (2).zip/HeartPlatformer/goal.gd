extends Area2D

# Optional: set Next Level in the Inspector (e.g. res://level2.tscn).
# If left empty, the flag automatically goes to the next numbered level
# (level1.tscn -> level2.tscn -> level3.tscn ...). If there is no next
# level, touching the flag just restarts the current level.
@export_file("*.tscn") var next_level: String


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _find_next_level() -> String:
	if next_level != "":
		return next_level
	var current: String = get_tree().current_scene.scene_file_path
	var regex := RegEx.new()
	regex.compile("level(\\d+)\\.tscn$")
	var m: RegExMatch = regex.search(current)
	if m:
		var candidate := "res://level%d.tscn" % (int(m.get_string(1)) + 1)
		if ResourceLoader.exists(candidate):
			return candidate
	return ""


func _on_body_entered(body: Node) -> void:
	if not body.is_in_group("player"):
		return
	var target := _find_next_level()
	if target != "":
		get_tree().change_scene_to_file.call_deferred(target)
	else:
		get_tree().reload_current_scene.call_deferred()
