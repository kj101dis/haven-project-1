extends CanvasLayer
# Always-on helper (set up as an Autoload in project.godot).
# Press 1, 2, 3 or 4 to jump straight to that level.
# Shows a small hint at the bottom-left, and any load error right on screen.

var label: Label


func _ready() -> void:
	layer = 100
	label = Label.new()
	label.position = Vector2(10, 620)
	label.add_theme_font_size_override("font_size", 14)
	label.text = "Press 1-4 to switch level"
	add_child(label)


func _unhandled_key_input(event: InputEvent) -> void:
	var key := event as InputEventKey
	if key == null or not key.pressed or key.echo:
		return
	var n := -1
	match key.keycode:
		KEY_1: n = 1
		KEY_2: n = 2
		KEY_3: n = 3
		KEY_4: n = 4
	if n == -1:
		return
	var path := "res://level%d.tscn" % n
	if not ResourceLoader.exists(path):
		label.text = "Missing file: " + path
		return
	var err := get_tree().change_scene_to_file(path)
	if err != OK:
		label.text = "Could not load %s (error %d) - see Output panel" % [path, err]
	else:
		label.text = "Press 1-4 to switch level"
