extends CanvasLayer

@export var level_number := 1

@onready var hearts_label: Label = $Board/HeartsLabel
@onready var level_label: Label = $Board/LevelLabel


func _ready() -> void:
	level_label.text = str(level_number)
	get_node("../Player").hearts_changed.connect(_on_hearts_changed)


func _on_hearts_changed(count: int) -> void:
	hearts_label.text = str(count)
