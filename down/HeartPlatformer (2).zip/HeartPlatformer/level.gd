extends Node2D
# Finds your PNGs in the project folder by name (see README):
#   pixilart-drawing*          -> background
#   pixil-frame*               -> platform tile
#   Cute_Hedgehog...removebg*  -> player (first frame of the sprite sheet)
#   Screenshot...removebg*     -> hearts
#   end.png                    -> end checkpoint (goal)
#   unnamed*                   -> score board (hearts box + level box)

const PLAYER_HEIGHT := 64.0
const HEART_SIZE := 36.0
const GOAL_HEIGHT := 56.0
const BOARD_SCALE := 3.0

# Crop areas inside your PNGs (x, y, width, height in image pixels).
# If you swap an image for a different one, adjust its crop here.
const HEDGEHOG_REGION := Rect2(5, 41, 125, 133)
const HEART_REGION := Rect2(21, 52, 482, 412)
const END_REGION := Rect2(26, 35, 32, 25)
const SCOREBOARD_REGION := Rect2(5, 27, 76, 30)


func _ready() -> void:
	_fix_physics()
	var p := _find_pngs()

	if p.has("bg"):
		$Background/TextureRect.texture = load(p["bg"])
	else:
		push_warning("Background (pixilart-drawing...) not found in res://")

	if p.has("platform"):
		var tile: Texture2D = load(p["platform"])
		for ground in $Platforms.get_children():
			ground.get_node("Tiles").texture = tile
	else:
		push_warning("Platform (pixil-frame...) not found in res://")

	if p.has("player"):
		var s := PLAYER_HEIGHT / HEDGEHOG_REGION.size.y
		_apply_region($Player/Sprite2D, load(p["player"]), HEDGEHOG_REGION, s)
		var shape := $Player/CollisionShape2D.shape as RectangleShape2D
		shape.size = Vector2(HEDGEHOG_REGION.size.x * s * 0.7, PLAYER_HEIGHT - 4.0)
	else:
		push_warning("Player (Cute_Hedgehog...removebg) not found in res://")

	if p.has("heart"):
		var ht: Texture2D = load(p["heart"])
		var hs := HEART_SIZE / HEART_REGION.size.x
		for heart in $Hearts.get_children():
			_apply_region(heart.get_node("Sprite2D"), ht, HEART_REGION, hs)
	else:
		push_warning("Hearts (Screenshot...removebg) not found in res://")

	if p.has("goal"):
		var gs := GOAL_HEIGHT / END_REGION.size.y
		_apply_region($Goal/Sprite2D, load(p["goal"]), END_REGION, gs)
	else:
		push_warning("End checkpoint (end.png) not found in res://")

	if p.has("board"):
		var atlas := AtlasTexture.new()
		atlas.atlas = _white_to_transparent(load(p["board"]))
		atlas.region = SCOREBOARD_REGION
		$HUD/Board/Frame.texture = atlas
	else:
		push_warning("Score board (unnamed...) not found in res://")


func _find_pngs() -> Dictionary:
	var out := {}
	for f in DirAccess.get_files_at("res://"):
		var fname: String = f.trim_suffix(".import")
		var lower := fname.to_lower()
		if not lower.ends_with(".png"):
			continue
		var path := "res://" + fname
		if lower.begins_with("screenshot") and "removebg" in lower:
			out["heart"] = path
		elif "removebg" in lower:
			out["player"] = path
		elif lower.begins_with("pixilart-drawing"):
			out["bg"] = path
		elif lower.begins_with("pixil-frame"):
			out["platform"] = path
		elif lower == "end.png":
			out["goal"] = path
		elif lower.begins_with("unnamed"):
			out["board"] = path
	return out


func _apply_region(spr: Sprite2D, tex: Texture2D, region: Rect2, s: float) -> void:
	spr.texture = tex
	spr.region_enabled = true
	spr.region_rect = region
	spr.scale = Vector2(s, s)


# The score board PNG has a white background; make it see-through.
func _white_to_transparent(tex: Texture2D) -> Texture2D:
	var img: Image = tex.get_image()
	img.convert(Image.FORMAT_RGBA8)
	for y in img.get_height():
		for x in img.get_width():
			var c := img.get_pixel(x, y)
			if c.r > 0.97 and c.g > 0.97 and c.b > 0.97:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
	return ImageTexture.create_from_image(img)


# Rebuilds all collisions in code so platforms are always solid,
# no matter how the scene file was imported.
func _fix_physics() -> void:
	var count := 0
	for body in $Platforms.get_children():
		if not (body is StaticBody2D):
			continue
		var rect: TextureRect = body.get_node("Tiles")
		var size := Vector2(rect.offset_right - rect.offset_left, rect.offset_bottom - rect.offset_top)
		for c in body.get_children():
			if c is CollisionShape2D:
				c.queue_free()
		var cs := CollisionShape2D.new()
		var rs := RectangleShape2D.new()
		rs.size = size
		cs.shape = rs
		cs.position = Vector2(rect.offset_left, rect.offset_top) + size / 2.0
		body.add_child(cs)
		body.collision_layer = 1
		body.collision_mask = 1
		count += 1

	var player: CharacterBody2D = $Player
	player.collision_layer = 1
	player.collision_mask = 1
	var pshape: CollisionShape2D = $Player/CollisionShape2D
	if pshape.shape == null:
		var prs := RectangleShape2D.new()
		prs.size = Vector2(40, 60)
		pshape.shape = prs
	pshape.disabled = false
	print("Platforms with collision: ", count, " | player shape size: ", (pshape.shape as RectangleShape2D).size)
